--The item level of each item
bossNameIndex = {
					["Onyxia"] = 5,
					
					-- molten core --
					["Lucifron"] = 5,
					["Magmadar"] = 5,
					["Gehennas"] = 5,
					["Garr"] = 5,
					["Baron Geddon"] = 5,
					["Shazzrah"] = 5,
					["Sulfuron Harbinger"] = 5,
					["Golemagg the Incinerator"] = 5,
					["Majordomo Executus"] = 5,
					["Ragnaros"] = 7,
					
					-- blackwing lair --
					["Razorgore the Untamed"] = 7,
					["Vaelastrasz the Corrupt"] = 7,
					["Broodlord Lashlayer"] = 7,
					["Firemaw"] = 7,
					["Ebonroc"] = 7,
					["Flamegor"] = 7,
					["Chromaggus"] = 7,
					["Nefarian"] = 10,

					-- zul'gurub --
					["High Priest Venoxis"] = 2,
					["High Priestess Jeklik"] = 2,
					["High Priestess Mar'li"] = 2,
					["High Priest Thekal"] = 2,
					["High Priestess Arlokk"] = 2,
					["Gri'lek"] = 2,
					["Hazza'rah"] = 2,
					["Renataki"] = 2,
					["Wushoolay"] = 2,
					["Bloodlord Mandokir"] = 2,
					["Jin'do the Hexxer"] = 2,
					["Gahz'ranka"] = 2,
					["Hakkar"] = 3,
					
					-- aq20 --
					["Kurinnaxx"] = 3,
					["General Rajaxx"] = 3,
					["Moam"] = 3,
					["Buru the Gorger"] = 3,
					["Ayamiss the Hunter"] = 3,
					["Ossirian the Unscarred"] = 4,
					
					-- aq40 --
					["The Prophet Skeram"] = 10,
					["Battleguard Sartura"] = 10,
					["Fankriss the Unyielding"] = 10,
					["Princess Huhuran"] = 10,
					["Princess Yauj"] = 10,
					["Vem"] = 10,
					["Lord Kri"] = 10,
					["Viscidus"] = 10,
					["Ouro"] = 10,
					["Emperor Vek'lor"] = 10,
					["Emperor Vek'nilash"] = 10,
					["C'Thun"] = 12,
					
					-- naxxramas --
					["Anub'Rekhan"] = 12,
					["Grand Widow Faerlina"] = 12,
					["Maexxna"] = 15,

					["Noth the Plaguebringer"] = 12,
					["Heigan the Unclean"] = 12,
					["Loatheb"] = 15,

					["Instructor Razuvious"] = 12,
					["Gothik the Harvester"] = 12,
					["Highlord Mograine"] = 15,
					["Thane Korth'azz"] = 15,
					["Lady Blaumeux"] = 15,
					["Sir Zeliek"] = 15,

					["Patchwerk"] = 12,
					["Grobbulus"] = 12,
					["Gluth"] = 12,
					["Thaddius"] = 15,

					["Sapphiron"] = 15,
					["Kel'Thuzad"] = 15,
					
					-- world bosses --
					["Doom Lord Kazzak"] = 7,
					["Azuregos"] = 7,
					["Teremus the Devourer"] = 7,
					["Emeriss"] = 7,
					["Lethon"] = 7,
					["Ysondre"] = 7,
					["Taerar"] = 7
				}